import ast, pathlib, subprocess, json, collections, hashlib
OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT.parents[1]/'hotel-herencia-auditoria'
GIT=['git','-c','safe.directory='+ROOT.as_posix()]
files=[pathlib.Path(x) for x in subprocess.check_output(GIT+['ls-files'],cwd=ROOT,text=True).splitlines()]
def read(p): return (ROOT/p).read_text(encoding='utf-8-sig')
tree=ast.parse(read(pathlib.Path('servicio/aplicacion.py')))
routes=[]
for f in ast.walk(tree):
    if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for d in f.decorator_list:
            if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and isinstance(d.func.value,ast.Name) and d.func.value.id=='app' and d.func.attr in ['get','post','delete','put','patch']:
                routes.append({'method':d.func.attr.upper(),'path':ast.literal_eval(d.args[0]),'line':f.lineno})
e2e={}
for p in (ROOT/'e2e').glob('*resultados.json'):
    rows=json.loads(p.read_text(encoding='utf-8'))
    e2e[p.name]={'count':len(rows),'states':dict(collections.Counter(x.get('estado') for x in rows))}
manifest=json.loads(read(pathlib.Path('docs/definicion-herencia/MANIFEST.json')))
hashes={'listed':len(manifest['files']),'same':0,'newline_only':[],'changed':[],'missing':[]}
requests=''.join('HEAD:docs/definicion-herencia/'+x['path']+'\n' for x in manifest['files'])
payload=subprocess.check_output(GIT+['cat-file','--batch'],cwd=ROOT,input=requests.encode())
offset=0
for x in manifest['files']:
    end=payload.index(b'\n',offset); header=payload[offset:end].decode(); offset=end+1
    if header.endswith(' missing'): hashes['missing'].append(x['path']); continue
    size=int(header.split()[-1]); blob=payload[offset:offset+size]; offset+=size+1
    if hashlib.sha256(blob).hexdigest()==x['sha256']: hashes['same']+=1
    elif hashlib.sha256(blob.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')).hexdigest()==x['sha256']: hashes['newline_only'].append(x['path'])
    else: hashes['changed'].append(x['path'])
tests=sum(sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(read(p)))) for p in files if p.as_posix().startswith('servicio/tests/test_') and p.suffix=='.py')
data={'commit':subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'tracked_files':len(files),'python_files':sum(p.suffix=='.py' for p in files),'code_lines':sum(len(read(p).splitlines()) for p in files if p.suffix in ['.py','.js','.jsx','.css']),'service_test_methods':tests,'routes':routes,'e2e_inherited':e2e,'manifest_git_blob':hashes,'largest_files':sorted([(len(read(p).splitlines()),p.as_posix()) for p in files if p.suffix in ['.py','.js','.jsx','.css']],reverse=True)[:8]}
(OUT/'inventario.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(data,ensure_ascii=False,indent=2))
