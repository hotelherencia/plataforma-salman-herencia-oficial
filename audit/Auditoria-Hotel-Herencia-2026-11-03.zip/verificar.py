import os, sys, pathlib, subprocess, json, io, unittest
from unittest.mock import patch

OUT = pathlib.Path(__file__).resolve().parent
REPO = OUT.parents[1] / 'hotel-herencia-auditoria'
sys.path.insert(0, str(REPO))
os.chdir(REPO)
results = []
for rel in ['core/incremento1','verticales/hotel/incremento0','verticales/hotel/incremento1','verticales/cafeteria/incremento1','verticales/inmobiliaria/incremento1','verticales/constructora/incremento1']:
    env = dict(os.environ, PYTHONPATH=str(REPO / rel), PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', rel+'/tests'], env=env, capture_output=True, text=True, encoding='utf-8')
    (OUT / (rel.replace('/','_')+'.log')).write_text(p.stdout+p.stderr, encoding='utf-8')
    results.append({'suite':rel,'exit':p.returncode,'summary':(p.stdout+p.stderr)[-300:]})

from servicio.aplicacion import crear_app
from servicio import seguridad, totp, google_oidc
from servicio.configuracion import Configuracion
from fastapi.testclient import TestClient

suite=unittest.defaultTestLoader.loadTestsFromNames(['servicio.tests.test_h1','servicio.tests.test_2fa.TotpRfcTest'])
buf=io.StringIO(); run=unittest.TextTestRunner(stream=buf,verbosity=2).run(suite)
(OUT/'servicio-sin-postgresql.log').write_text(buf.getvalue(),encoding='utf-8')
results.append({'suite':'servicio sin PostgreSQL','tests':run.testsRun,'failures':len(run.failures),'errors':len(run.errors)})

class FakeDB:
    def __init__(self): self.enabled=True; self.secret=totp.generar_secreto(); self.row=None; self.sql=[]
    def execute(self, sql, params=()):
        self.sql.append(sql)
        if 'SET totp_secreto = %s, totp_activado = FALSE' in sql: self.enabled=False; self.secret=params[0]
        if 'SET totp_activado = FALSE, totp_secreto = NULL' in sql: self.enabled=False; self.secret=None
        if 'SELECT totp_secreto' in sql: self.row=(self.secret,)
        elif 'SELECT id, empresa_id, rol, nombre FROM usuarios WHERE email' in sql:
            self.row=None if 'activo = true' in sql.lower() else ('U-disabled','EMP-SINTETICA-001','administrador','disabled')
        else: self.row=None
        return self
    def fetchone(self): return self.row
    def commit(self): pass

db=FakeDB()
config=Configuracion('127.0.0.1',0,None,False,None,None,None,google_client_id='synthetic-client',google_client_secret='synthetic-secret')
app=crear_app(configuracion=config)
def deps(dependant):
    for d in dependant.dependencies:
        yield d.call
        yield from deps(d)
for route in app.routes:
    if hasattr(route,'dependant'):
        for dep in deps(route.dependant):
            if dep.__name__=='_conexion': app.dependency_overrides[dep]=lambda: db
client=TestClient(app)
session=seguridad.SesionActiva('synthetic','U','EMP-SINTETICA-001','administrador','synthetic')
proof=[]
with patch.object(seguridad,'obtener_sesion_activa',return_value=session):
    client.cookies.set('sid','synthetic')
    db.enabled=True
    r=client.post('/cuenta/2fa')
    proof.append({'id':'SEC-A02','test':'Iniciar alta sobre cuenta ya protegida sin código ni clave','status':r.status_code,'totp_enabled_after':db.enabled})
    db.enabled=True
    r=client.delete('/cuenta/2fa')
    proof.append({'id':'SEC-A02b','test':'Desactivar 2FA sin código ni clave','status':r.status_code,'totp_enabled_after':db.enabled})
    db.secret=totp.generar_secreto(); db.enabled=True
    r=client.get('/cuenta/2fa/qr')
    proof.append({'id':'SEC-A02c','test':'QR del secreto vigente con sesión sin reautenticar','status':r.status_code,'svg_returned':'<svg' in r.text})
    foreign=seguridad.SesionActiva('synthetic','U','EMP-OTRA','administrador','synthetic')
    with patch.object(seguridad,'obtener_sesion_activa',return_value=foreign), patch('servicio.reservas.listar_habitaciones',return_value=[{'habitacion_id':'HAB-PRIVADA'}]) as read:
        r=client.get('/hotel/habitaciones')
        proof.append({'id':'SEC-A04','test':'Sesión de otra empresa alcanza lectura de inventario compartido','status':r.status_code,'inventory_function_called':read.called})

client.cookies.clear()
state=app.state.estados_oauth.nuevo()
with patch.object(google_oidc,'intercambiar_codigo',return_value={'id_token':'synthetic'}), patch.object(google_oidc,'verificar_id_token',return_value={'email':'disabled@example.invalid'}), patch.object(seguridad,'crear_sesion',return_value='synthetic-disabled'):
    r=client.get('/auth/google/callback',params={'state':state,'code':'synthetic'},follow_redirects=False)
    proof.append({'id':'SEC-A01','test':'Callback sin cookie de navegador y usuario inactivo simulado','status':r.status_code,'sid_set':bool(r.cookies.get('sid')),'active_filter_in_lookup':any('WHERE email' in s and 'activo = true' in s.lower() for s in db.sql)})

client.cookies.clear()
with patch.object(seguridad,'autenticar',return_value=('U','EMP-SINTETICA-001','administrador',True)), patch.object(seguridad,'secreto_totp',return_value=totp.generar_secreto()), patch.object(totp,'verificar',return_value=False):
    statuses=[client.post('/sesion',json={'usuario':'synthetic','clave':'synthetic','totp':'000000'}).status_code for _ in range(8)]
    proof.append({'id':'SEC-A03','test':'Ocho TOTP incorrectos con primera clave válida','statuses':statuses,'rate_limited':429 in statuses})

(OUT/'verificaciones.json').write_text(json.dumps({'tests':results,'security_proofs':proof,'limits':'Pruebas HTTP con persistencia simulada; sin PostgreSQL ni servicios externos. No representan explotación productiva.'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'tests':results,'security_proofs':proof},ensure_ascii=False,indent=2))
